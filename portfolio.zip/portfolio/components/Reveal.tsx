'use client';
import {useEffect,useRef,ReactNode,CSSProperties,ElementType} from 'react';
export default function Reveal({children,delay=0,className='',as:T='div'}:{children:ReactNode;delay?:number;className?:string;as?:ElementType}){
  const r=useRef<HTMLElement>(null);
  useEffect(()=>{const el=r.current;if(!el)return;const o=new IntersectionObserver(([e])=>{if(e.isIntersecting){el.classList.add('in');o.disconnect()}},{threshold:.15});o.observe(el);return()=>o.disconnect()},[]);
  return <T ref={r} className={`reveal ${className}`} style={{'--d':`${delay}ms`} as CSSProperties}>{children}</T>}
